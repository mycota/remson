<?php

echo getcwd()."<br>";

chdir("../../");
echo getcwd()."<br>";
chdir("../../../");
echo getcwd();

?>