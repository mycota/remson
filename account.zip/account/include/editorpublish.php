	<?php 
		
			echo "<script>alert('All is set.....'); window.location='./products.php?source=draft_news'</script>";
		
	?>
