### Features

* Default option allows showing a checkbox.
* Ability to grouping elements.
* Supports to show multiple items in a single row.
* Select all options.
* Feature to show placeholder.
