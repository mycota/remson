		
<?php ob_start(); ?>
<?php include "../resources/db_funct/db.php"; 
      include "../resources/db_funct/function.php";  
      session_start();
      if (!isset($_SESSION['username'])) {
        if(!isset($_SESSION['role'])){
          if ($_SESSION['role'] != 'Admin') {
            
         header("Location: ../../logout.php");         
         //../index.php

        }
     }
   }
$error = '';
	if (!empty($_POST)) {

		$proid = mysqli($_POST['item']);
		$rest = '';

				   $query = mysqli_prepare($con,"UPDATE tbl_products SET orderDel = ? WHERE  SERIAL = ?");
				   mysqli_stmt_bind_param($query,"sd", $rest, $proid);
				   mysqli_stmt_execute($query);

  					confirmQuery($query);
  					header("Location: ./orders.php");

  					
	}
	?>
