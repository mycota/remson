<?php

$arrayCountry = array('');
?>