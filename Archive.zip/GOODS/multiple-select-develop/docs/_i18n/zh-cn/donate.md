Multiple Select 是我个人利用业余时间制作的免费插件。

如果在你的项目中 Multiple Select 帮助到了你，可以对 Multiple Select 进行捐助。

相信有了你的帮助，Multiple Select 一定会继续努力做得更好。
