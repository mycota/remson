<?php 

function mysqli($data){

  global $con;

  return mysqli_real_escape_string($con,$data);

}
function uniqids() {
    $chars = "003232303232023232023456789";
    srand((double)microtime()*1000000);
    $i = 0;
    $pass = '' ;
    while ($i <= 7) {

        $num = rand() % 33;

        $tmp = substr($chars, $num, 1);

        $pass = $pass . $tmp;

        $i++;

    }
    return $pass;
}

$jobNumber = 'JOB-'.uniqids();


function confirmQuery($result){
      
      global $con;
    
    if (!$result) {
      die("Query Failed !!" .mysqli_error($con));
    }
}

function logs($userID, $user, $action){
      global $con;

  $userid = mysqli_real_escape_string($con,$userID);
  $logaction = mysqli_real_escape_string($con,$action);

  $insert_query = mysqli_prepare($con,"INSERT INTO tbl_logs (userID, user_name, log_action) VALUES(?,?,?)");
  mysqli_stmt_bind_param($insert_query,"dss", $userid, $user, $logaction);
  mysqli_stmt_execute($insert_query);
  confirmQuery($insert_query);
  
}

function encrypt($pas){

  $hashformat = "$2y$10$";
    $salt = "iloveyouGodcositisyou1";
    $hashsalt = $hashformat.$salt;
    $pass = crypt($pas,$hashsalt);

    return $pass;
    }


function pass($pwd){
$error='';
if( strlen($pwd) < 10 ) {
$error .= "Password too short! 
";
}

if( !preg_match("#[0-9]+#", $pwd) ) {
$error .= "Password must include at least one number! 
";
}

if( !preg_match("#[a-z]+#", $pwd) ) {
$error .= "Password must include at least one letter! 
";
}

if( !preg_match("#[A-Z]+#", $pwd) ) {
$error .= "Password must include at least one CAPS! 
";
}

if( !preg_match("#\W+#", $pwd) ) {
$error .= "Password must include at least one symbol! 
";
}

if($error){
return "Password validation failure(your choise is weak): $error";
}
}
?>
<!-- Print function -->
<script type="text/javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=800, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('</head><body onLoad="self.print()" style="width: 800px; font-size: 13px; font-family: arial;">');          
   docprint.document.write(content_vlue); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>